package entity;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Venda implements Serializable {

    static SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:SS");
    private Integer idVenda=0;
    private Double total = 0.;
    private Date dataVenda = new Date();

    private List<Produto> lista;

    public Venda() {
    }

    public Venda(Integer idVenda, Double total, Date dataVenda, List<Produto> lista) {
        this.idVenda = idVenda;
        this.total = total;
        this.dataVenda = dataVenda;
        this.lista = lista;
    }

    @Override
    public String toString() {
        return "Venda{" +
                "idVenda=" + idVenda +
                ", total=" + total +
                ", dataVenda=" + dataVenda +
                ", lista=" + lista +
                '}';
    }

    public Integer getIdVenda() {
        return idVenda;
    }

    public void setIdVenda(Integer idVenda) {
        this.idVenda = idVenda;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public Date getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(Date dataVenda) {
        this.dataVenda = dataVenda;
    }

    public List<Produto> getLista() {
        return lista;
    }

    public void setLista(List<Produto> lista) {
        this.lista = lista;
    }
}

package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import entity.Venda;

public class Tela3 extends AppCompatActivity {

    Venda venda;
    TextView valortotal, vprodutos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela3);
        Intent it = getIntent();
        Bundle dados = it.getExtras();
        venda = new Venda();
        venda = (Venda) dados.getSerializable("Managercesta");
        Toast.makeText(getApplicationContext(), "Valor da Venda:" + venda.getTotal(), Toast.LENGTH_LONG).show();
        valortotal = findViewById(R.id.valortotal);

        valortotal.setText("R$" + venda.getTotal());
    }
}

package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;

import java.util.List;

import adapter.ItemAdapter;
import manager.ManagerMock;

public class MainActivity extends AppCompatActivity {

    ItemAdapter adapter;
    ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        adapter = new ItemAdapter(this, ManagerMock.getProdutos());
        lista = findViewById(R.id.lista);
        lista.setAdapter(adapter);

        ImageButton carrinho = findViewById(R.id.carrinho);

        carrinho.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(v.getContext(), Tela2.class);
                startActivity(it);
            }
        });
    }


}

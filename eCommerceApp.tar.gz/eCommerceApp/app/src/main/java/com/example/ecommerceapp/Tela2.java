package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;

import java.util.Date;

import adapter.ItemAdapter;
import adapter.ItemAdapterFinal;
import entity.Venda;
import manager.ManagerCesta;

public class Tela2 extends AppCompatActivity {

    ItemAdapterFinal adapter2;
    ListView lista2;
    Venda venda;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        lista2 = findViewById(R.id.lista2);
        adapter2 = new ItemAdapterFinal(this, ManagerCesta.getProdutos());
        lista2.setAdapter(adapter2);
        ImageButton cmdTotal = findViewById(R.id.btn3);

        cmdTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                venda = new Venda();
                venda.setTotal(ManagerCesta.total);
                venda.setLista(ManagerCesta.getProdutos());
                Intent it = new Intent(getApplicationContext(), Tela3.class);
                Bundle b = new Bundle();
                b.putSerializable("Managercesta", venda);
                it.putExtras(b);
                startActivity(it);
            }
        });
    }
}

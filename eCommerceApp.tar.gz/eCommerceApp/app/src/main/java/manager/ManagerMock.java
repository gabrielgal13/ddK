package manager;

import java.util.ArrayList;

import entity.Produto;

public class ManagerMock {
    private static final ArrayList<Produto> produtos = new ArrayList<>();

    static {
        int id=1;

        produtos.add(new Produto(id++,"iphone",150.));
        produtos.add(new Produto(id++, "samsung", 100.));
        produtos.add(new Produto(id++, "playstation", 200.));
        produtos.add(new Produto(id++, "nokia",50.));
    }

    public static ArrayList<Produto> getProdutos () {
        return produtos;
    }
}

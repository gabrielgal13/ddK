package com.example.barsimpsons;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import entity.Pessoa;
import entity.Produto;
import entity.Venda;
import http.HttpConnection;
import manager.ManagerCesta;

public class TelaUsuario extends AppCompatActivity {
    Pessoa pessoa;
    ArrayList<Produto> lista1;
    TextView txtNome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_usuario);
        Intent it = getIntent();
        Bundle bundle = it.getExtras();
        pessoa = (Pessoa) bundle.getSerializable("pessoa");
         txtNome = findViewById(R.id.txtNome);

        txtNome.setText(pessoa.getNome().toString());

        ImageButton botaorelatorio = findViewById(R.id.relatorio);
        ImageButton botaopedido = findViewById(R.id.pedido);

        botaopedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ArrayList<Produto> lista1 = new ArrayList<>();
                    ManagerCesta.produtos.clear();
                    new AsyncObjeto(getApplicationContext(), lista1).execute();
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "ERROR:", Toast.LENGTH_LONG).show();
                }
            }
        });

        botaorelatorio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ArrayList<Venda> lista1 = new ArrayList<>();
                    lista1.clear();
                    new AsyncVendas(getApplicationContext(), lista1).execute();
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "ERROR:", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

        public class AsyncObjeto extends AsyncTask<String, Void, String> {
            Context context;
            ArrayList<Produto> lista1;
            Produto produto;

            public AsyncObjeto(Context ctx, ArrayList<Produto> lista) {
                this.context = ctx;
                this.lista1 = lista;
            }

            @Override
            protected String doInBackground(String... strings) {
                String resposta = "";
                try {
                    resposta = HttpConnection.httpGet("http://192.168.1.151:3008/produtos");

                    return resposta;
                } catch (Exception ex) {
                    return ex.getMessage();
                }
            }

            @Override
            protected void onPostExecute(String resposta) {
                try {

                    JSONArray jsonAr = new JSONArray(resposta);
                    Produto p = new Produto();
                    final ArrayList<Produto> lista1 = new ArrayList<>();
                    for (int i = 0; i < jsonAr.length(); i++) {
                        JSONObject jsonObj = jsonAr.getJSONObject(i);
                        String id = jsonObj.getString("id");
                        String nome = jsonObj.getString("nome");
                        String preco = jsonObj.getString("preco");
                        String quantidade = jsonObj.getString("quantidade");

                        Integer idInt = Integer.valueOf(id);
                        Double precoDouble = Double.valueOf(preco);
                        Integer QuantidadeInt = Integer.valueOf(quantidade);

                        lista1.add(new Produto(idInt, nome, precoDouble, QuantidadeInt));
                    }

                    Intent it = new Intent(getApplicationContext(), Ecommerce.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("lista", lista1);
                    bundle.putSerializable("pessoa", pessoa);
                    it.putExtras(bundle);
                    startActivity(it);


                } catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), "ERROR:" + ex.getMessage(), Toast.LENGTH_LONG).show();
                }

            }
        }

    public class AsyncVendas extends AsyncTask<String, Void, String> {
        Context context;
        ArrayList<Venda> lista1;

        public AsyncVendas(Context ctx, ArrayList<Venda> lista) {
            this.context = ctx;
            this.lista1 = lista;
        }

        @Override
        protected String doInBackground(String... strings) {
            String resposta = "";
            try {
                resposta = HttpConnection.httpGet("http://192.168.1.151:3008/vendas/" + pessoa.getNome());
                return resposta;
            } catch (Exception ex) {
                return ex.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String resposta) {
            try {
                if(resposta.length() < 5) {
                    Toast.makeText(getApplicationContext(), "Não possui nenhum Registro.", Toast.LENGTH_LONG).show();
                }
                JSONArray jsonAr = new JSONArray(resposta);
                Venda v = new Venda();
                final ArrayList<Venda> lista1 = new ArrayList<>();
                for (int i = 0; i < jsonAr.length(); i++) {
                    JSONObject jsonObj = jsonAr.getJSONObject(i);
                    String data = jsonObj.getString("data");
                    String nome = jsonObj.getString("NomeCliente");
                    String produtos = jsonObj.getString("produtos");
                    String total = jsonObj.getString("total");
                    ArrayList<Produto> produtos1 = new ArrayList<>();
                    produtos1.add(new Produto(null, produtos, null, null));
                    Double totalD = Double.valueOf(total);

                    lista1.add(new Venda(0, totalD, data, nome, produtos1));
                }

                Intent it = new Intent(getApplicationContext(), RelatorioCliente.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("lista", lista1);
                it.putExtras(bundle);
                startActivity(it);


            } catch (Exception ex) {
                Toast.makeText(getApplicationContext(), "ERROR:" + ex.getMessage(), Toast.LENGTH_LONG).show();
            }

        }
        }
    }


package com.example.barsimpsons;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import async.ProdutoCadastrarAsync;
import entity.Produto;
import http.HttpConnection;

public class AdicionarProduto extends AppCompatActivity {

    TextView txtNomeProduto, txtPreco, txtQuantidade;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adicionar_produto);
    }

    public void gravar(View v) {
        try {
            Produto produto = new Produto();
            txtNomeProduto = findViewById(R.id.txtNomeProduto);
            txtPreco = findViewById(R.id.txtPreco);
            Double preco = Double.parseDouble(txtPreco.getText().toString());

            txtQuantidade = findViewById(R.id.txtQuantidade);

            Integer quantidade = Integer.parseInt(txtQuantidade.getText().toString());

            produto.setNomeProduto(txtNomeProduto.getText().toString());
            produto.setPreco(preco);
            produto.setQuantidade(quantidade);

            new AsyncId(getApplicationContext(), produto).execute();

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    public class AsyncId extends AsyncTask<String, Void, String> {
        Context context;
        Produto produto;

        public AsyncId(Context ctx, Produto produto) {
            this.context = ctx;
            this.produto = produto;
        }

        @Override
        protected String doInBackground(String... strings) {
            String resposta = "";
            try {
                resposta = HttpConnection.httpGet("http://192.168.1.151:3008/produtos");

                return resposta;
            } catch (Exception ex) {
                return ex.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String resposta) {
            try {

                JSONArray jsonAr = new JSONArray(resposta);
                Produto p = new Produto();
                for (int i = 0; i < jsonAr.length(); i++) {
                    JSONObject jsonObj = jsonAr.getJSONObject(i);
                    String id = jsonObj.getString("id");

                    Integer idInt = Integer.valueOf(id);
                    idInt++;
                    produto.setId(idInt);
                }

                new ProdutoCadastrarAsync(getApplicationContext(), produto).execute();



            } catch (Exception ex) {
                Toast.makeText(getApplicationContext(), "ERROR:" + ex.getMessage(), Toast.LENGTH_LONG).show();
            }

        }
    }


}

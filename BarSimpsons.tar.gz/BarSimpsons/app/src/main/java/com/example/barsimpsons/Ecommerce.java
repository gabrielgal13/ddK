package com.example.barsimpsons;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import java.util.ArrayList;
import adapter.ItemAdapter;
import entity.Pessoa;
import entity.Produto;

public class Ecommerce extends AppCompatActivity {

    ItemAdapter adapter;
    ListView lista;
    ArrayList<Produto> lista1;
    Pessoa pessoa;
    Produto produto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ecommerce);
        Intent it = getIntent();
        Bundle bundle = it.getExtras();
        pessoa = (Pessoa) bundle.getSerializable("pessoa");
        ArrayList<Produto> lista1 = (ArrayList) bundle.getSerializable("lista");

        adapter = new ItemAdapter(this, lista1);

        lista = findViewById(R.id.lista);
        lista.setAdapter(adapter);

        ImageButton carrinho = findViewById(R.id.carrinho);

        carrinho.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(), Ecommerce2.class);
                Bundle b = new Bundle();
                b.putSerializable("pessoa", pessoa);
                it.putExtras(b);
                startActivity(it);
            }
        });


    }



    }

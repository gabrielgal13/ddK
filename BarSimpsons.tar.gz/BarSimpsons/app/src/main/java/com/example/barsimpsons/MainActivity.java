package com.example.barsimpsons;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import entity.Pessoa;
import http.HttpConnection;

public class MainActivity extends AppCompatActivity {

    EditText txtLogin, txtSenha;
    Pessoa pessoa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtLogin = findViewById(R.id.txtLogin);
        txtSenha = findViewById(R.id.txtSenha);
    }

    public void logar(View v) {
        try {
            pessoa = new Pessoa();
            pessoa.setLogin(txtLogin.getText().toString());
            pessoa.setSenha(txtSenha.getText().toString());
            int flag = 0;
            new AsyncLogin(getApplicationContext(), pessoa).execute();

        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "ERROR:", Toast.LENGTH_LONG).show();
        }
    }

    public void registro(View v) {
        Intent it = new Intent(this, Registrar.class);
        startActivity(it);
    }

    public class AsyncLogin extends AsyncTask<String, Void, String> {
        Context context;
        Pessoa pessoa;

        public AsyncLogin(Context ctx, Pessoa p) {
            this.context = ctx;
            this.pessoa = p;
        }

        @Override
        protected String doInBackground(String... strings) {
            String resposta ="";
            try {
                resposta = HttpConnection.httpGet("http://192.168.1.151:3008/pessoa/logar/" + pessoa.getLogin() + "/" + pessoa.getSenha());
                return resposta;
            } catch (Exception ex) {
                return ex.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String resposta) {
            try {
                JSONArray jsonAr = new JSONArray(resposta);
                JSONObject jsonObj = jsonAr.getJSONObject(0);

                String nome = jsonObj.getString("nome");
                String priori = jsonObj.getString("prioridade");
                String email = jsonObj.getString("email");
                String cep = jsonObj.getString("cep");
                String logradouro = jsonObj.getString("logradouro");
                String bairro = jsonObj.getString("bairro");
                String cidade = jsonObj.getString("cidade");
                String estado = jsonObj.getString("estado");

                pessoa.setNome(nome);
                pessoa.setPrioridade(Integer.valueOf(priori));
                pessoa.setEmail(email);
                pessoa.setCep(cep);
                pessoa.setLogradouro(logradouro);
                pessoa.setBairro(bairro);
                pessoa.setCidade(cidade);
                pessoa.setEstado(estado);

                if (pessoa.getPrioridade() == 2)  {
                    Intent it = new Intent(getApplicationContext(), TelaUsuario.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("pessoa", pessoa);
                    it.putExtras(bundle);
                    startActivity(it);
                }
                if (pessoa.getPrioridade() == 1) {
                    Intent it = new Intent(getApplicationContext(), TelaAdministrador.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("pessoa", pessoa);
                    it.putExtras(bundle);
                    startActivity(it);
                }


            } catch (Exception ex){
                Toast.makeText(getApplicationContext(), "ERROR:" + ex.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }
}

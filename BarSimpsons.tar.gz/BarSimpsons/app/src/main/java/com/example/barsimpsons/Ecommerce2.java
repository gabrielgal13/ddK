package com.example.barsimpsons;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import java.text.SimpleDateFormat;
import java.util.Date;
import adapter.ItemAdapterFinal;
import entity.Pessoa;
import entity.Venda;
import manager.ManagerCesta;

public class Ecommerce2 extends AppCompatActivity {

    ItemAdapterFinal adapter2;
    ListView lista2;
    Venda venda;
    Pessoa pessoa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ecommerce2);
        Intent it = getIntent();
        Bundle bundle = it.getExtras();
        pessoa = (Pessoa) bundle.getSerializable("pessoa");
        lista2 = findViewById(R.id.lista2);
        adapter2 = new ItemAdapterFinal(this, ManagerCesta.getProdutos());
        lista2.setAdapter(adapter2);
        ImageButton cmdTotal = findViewById(R.id.btn3);

        cmdTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SimpleDateFormat formataData = new SimpleDateFormat("dd-MM-yyyy HH:mm");
                Date data = new Date();
                String dataFormatada = formataData.format(data);
                venda = new Venda();
                venda.setDataVenda(dataFormatada);
                venda.setTotal(ManagerCesta.total);
                venda.setLista(ManagerCesta.getProdutos());
                venda.setNome(pessoa.getNome());

                Intent it = new Intent(getApplicationContext(), ConcluirVenda.class);
                Bundle b = new Bundle();
                b.putSerializable("Managercesta", venda);
                it.putExtras(b);
                startActivity(it);
            }
        });
    }
}

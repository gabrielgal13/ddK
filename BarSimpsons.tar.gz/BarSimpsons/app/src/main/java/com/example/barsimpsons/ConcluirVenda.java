package com.example.barsimpsons;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import async.VendaCadastrarAsync;
import entity.Venda;

public class ConcluirVenda extends AppCompatActivity {

    Venda venda;
    TextView valortotal, vprodutos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_concluir_venda);
        Intent it = getIntent();
        Bundle dados = it.getExtras();
        venda = new Venda();
        venda = (Venda) dados.getSerializable("Managercesta");
        valortotal = findViewById(R.id.valortotal);
        valortotal.setText("R$" + venda.getTotal());
        new VendaCadastrarAsync(getApplicationContext(), venda).execute();

    }

}

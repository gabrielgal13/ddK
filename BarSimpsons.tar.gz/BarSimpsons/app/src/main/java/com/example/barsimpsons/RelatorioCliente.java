package com.example.barsimpsons;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import java.util.ArrayList;
import adapter.VendaAdapter;
import entity.Venda;

public class RelatorioCliente extends AppCompatActivity {

    VendaAdapter adapter;
    ListView lista;
    ArrayList<Venda> lista1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relatorio);
        Intent it = getIntent();
        Bundle bundle = it.getExtras();
        ArrayList<Venda> lista1 = (ArrayList) bundle.getSerializable("lista");

        adapter = new VendaAdapter(this, lista1);

        lista = findViewById(R.id.lista);
        lista.setAdapter(adapter);
    }
}


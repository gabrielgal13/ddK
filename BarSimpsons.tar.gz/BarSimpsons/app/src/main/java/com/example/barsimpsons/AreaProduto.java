package com.example.barsimpsons;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.ArrayList;
import async.AlteraProdutoAsync;
import entity.Produto;

public class AreaProduto extends AppCompatActivity {

    EditText txtNome, txtPreco, txtQuantidade;
    Spinner spprodutos;
    Produto produto;
    ArrayList<Produto> produtos;
    ArrayAdapter<Produto> adapter;
    int pos=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area_produto);
        Intent it = getIntent();
        Bundle bundle = it.getExtras();
        ArrayList<Produto> lista1 = (ArrayList) bundle.getSerializable("lista");
        produtos = lista1;
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, produtos);
        spprodutos = findViewById(R.id.spprodutos);
        spprodutos.setAdapter(adapter);

        txtNome = findViewById(R.id.txtNome);
        txtPreco = findViewById(R.id.txtPreco);
        txtQuantidade = findViewById(R.id.txtQuantidade);


        spprodutos.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int i, long id) {
                pos = i;
                produto = produtos.get(i);
                produtos.set(i,produto);
                Toast.makeText(getApplicationContext(), produto.toString(), Toast.LENGTH_LONG).show();

                txtNome.setText(produto.getNomeProduto());
                txtPreco.setText(produto.getPreco().toString());
                txtQuantidade.setText(produto.getQuantidade().toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void alteraProduto(View v) {

        produto.setNomeProduto(txtNome.getText().toString());
        produto.setPreco(Double.valueOf(txtPreco.getText().toString()));
        produto.setQuantidade(Integer.valueOf(txtQuantidade.getText().toString()));

        new AlteraProdutoAsync(getApplicationContext(), produto).execute();

    }

}


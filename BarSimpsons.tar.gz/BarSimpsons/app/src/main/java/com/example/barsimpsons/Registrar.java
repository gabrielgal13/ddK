package com.example.barsimpsons;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import async.UsuarioCadastrarAsync;
import entity.Pessoa;
import http.HttpConnection;

public class Registrar extends AppCompatActivity {

    EditText txtNomeCompleto, txtLogin, txtSenha, txtEmail,  txtCep, txtLogradouro, txtBairro, txtCidade, txtEstado;
    Pessoa pessoa;
    String buscaCep;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);
        pessoa = new Pessoa();
        txtNomeCompleto = findViewById(R.id.txtNomeCompleto);
        txtLogin = findViewById(R.id.txtLogin);
        txtSenha = findViewById(R.id.txtSenha);
        txtEmail = findViewById(R.id.txtEmail);
        txtCep = findViewById(R.id.txtCep);
        txtLogradouro = findViewById(R.id.txtLogradouro);
        txtBairro = findViewById(R.id.txtBairro);
        txtCidade = findViewById(R.id.txtCidade);
        txtEstado = findViewById(R.id.txtEstado);

    }

    public void buscar(View v) {
        try {
            buscaCep = txtCep.getText().toString();
            new AsyncCep(getApplicationContext(), pessoa).execute();
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), "ERROR:", Toast.LENGTH_LONG).show();
        }
    }

    public void gravar(View v) {
        try {
            pessoa.setNome(txtNomeCompleto.getText().toString());
            pessoa.setEmail(txtEmail.getText().toString());
            pessoa.setLogin(txtLogin.getText().toString());
            pessoa.setSenha(txtSenha.getText().toString());
            pessoa.setCep(txtCep.getText().toString());
            pessoa.setLogradouro(txtLogradouro.getText().toString());
            pessoa.setEstado(txtEstado.getText().toString());
            pessoa.setBairro(txtBairro.getText().toString());
            pessoa.setEstado(txtEstado.getText().toString());

            new UsuarioCadastrarAsync(getApplicationContext(), pessoa).execute();
            Toast.makeText(getApplicationContext(),
                    "Usuário Registrado:",Toast.LENGTH_LONG).show();
            Toast.makeText(getApplicationContext(), "Gravados:" + pessoa, Toast.LENGTH_LONG).show();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public class AsyncCep extends AsyncTask<String, Void, String> {
        Context context;
        Pessoa pessoa;

        public AsyncCep(Context ctx, Pessoa c) {
            this.context = ctx;
            this.pessoa = c;
        }

        @Override
        protected String doInBackground(String... strings) {
            String resposta = "";
            try {
                resposta = HttpConnection.httpGet("http://api.postmon.com.br/cep/" + buscaCep);
                return resposta;
            } catch (Exception ex) {
                return ex.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String resposta) {
            try {
                JSONObject obj = new JSONObject(resposta);
                String logradouro = obj.getString("logradouro");
                String bairro = obj.getString("bairro");
                String cidade = obj.getString("cidade");
                String estado = obj.getString("estado");
                String cep = obj.getString("cep");
                pessoa.setBairro(bairro);
                pessoa.setLogradouro(logradouro);
                pessoa.setCidade(cidade);
                pessoa.setEstado(estado);
                pessoa.setCep(cep);



                txtBairro.setText(bairro);
                txtLogradouro.setText(logradouro);
                txtCidade.setText(cidade);
                txtEstado.setText(estado);
                txtCep.setText(cep);


            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}

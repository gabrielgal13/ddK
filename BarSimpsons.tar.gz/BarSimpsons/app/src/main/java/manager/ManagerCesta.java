package manager;


import java.util.ArrayList;

import entity.Produto;

public class ManagerCesta {

    public static ArrayList<Produto> produtos = new ArrayList<>();
    public static Double total = 0.;
    public static ArrayList<Produto> getProdutos(){
        return produtos;
    }
}

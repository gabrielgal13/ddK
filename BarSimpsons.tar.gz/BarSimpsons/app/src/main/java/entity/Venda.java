package entity;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Venda implements Serializable {

    private Integer idVenda=0;
    private Double total = 0.;
    private String dataVenda;
    private String nome;
    private String poduto;
    private List<Produto> lista;

    public Venda() {
    }


    public Venda(Integer idVenda, Double total, String dataVenda, String nome, List<Produto> lista) {
        this.idVenda = idVenda;
        this.total = total;
        this.dataVenda = dataVenda;
        this.nome = nome;
        this.lista = lista;
    }



    @Override
    public String toString() {
        return "Venda{" +
                "idVenda=" + idVenda +
                ", total=" + total +
                ", dataVenda=" + dataVenda +
                ", lista=" + lista +
                '}';
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getIdVenda() {
        return idVenda;
    }

    public void setIdVenda(Integer idVenda) {
        this.idVenda = idVenda;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public String getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(String dataVenda) {
        this.dataVenda = dataVenda;
    }

    public List<Produto> getLista() {
        return lista;
    }

    public void setLista(List<Produto> lista) {
        this.lista = lista;
    }
}

package entity;

import com.example.barsimpsons.R;

import java.io.Serializable;

public class Produto implements Serializable {
    private Integer id=0;
    private String nomeProduto;
    private Double preco;
    private Integer quantidade;
    private Integer foto;

    public Produto() {
    }

    public Produto(Integer id, String nomeProduto, Double preco, Integer quantidade) {
        this.id = id;
        this.nomeProduto = nomeProduto;
        this.preco = preco;
        this.quantidade = quantidade;
    }


    @Override
    public String toString() {
        return  nomeProduto;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public Integer getFoto() {
        return foto;
    }

    public void setFoto(Integer foto) {
        this.foto = foto;
    }

    public void escolha (String msg) {
        if (this.nomeProduto.equalsIgnoreCase("Iphone")) {
            this.setFoto(R.drawable.iphone);
        } else if (this.nomeProduto.equalsIgnoreCase("Samsung")) {
            this.setFoto(R.drawable.samsung);
        } else if (this.nomeProduto.equalsIgnoreCase("Playstation")) {
            this.setFoto(R.drawable.playstation);
        } else if (this.nomeProduto.equalsIgnoreCase("Nokia")) {
            this.setFoto(R.drawable.nokia);
        }
    }
}

package adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import com.example.barsimpsons.Ecommerce2;
import com.example.barsimpsons.R;
import java.util.ArrayList;
import entity.Produto;
import manager.ManagerCesta;

public class ItemAdapterFinal extends BaseAdapter {
    ArrayList<Produto> lista;
    Context ctx;
    LayoutInflater layout;

    public ItemAdapterFinal(Context ctx, ArrayList<Produto> lista) {
        this.lista = lista;
        this.ctx = ctx;
        layout = LayoutInflater.from(ctx);
    }

    public int getCount(){
        return lista.size();
    }

    public Object getItem(int i){
        return lista.get(i);
    }
    public long getItemId(int pos) {
        return lista.get(pos).getId();
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        final Produto item = (Produto) getItem(i);
        view = layout.inflate(R.layout.produto2, null);

        TextView viewNome = (TextView) view.findViewById(R.id.viewNome);
        TextView viewPreco = (TextView) view.findViewById(R.id.viewPreco);

        viewNome.setText(item.getNomeProduto());
        viewPreco.setText("¢" + item.getPreco());

        Button cmdRemover = view.findViewById(R.id.btn4);

        cmdRemover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ManagerCesta.produtos.remove(item);
                ManagerCesta.total -= item.getPreco();
                Intent it = new Intent(v.getContext(), Ecommerce2.class);
                ctx.startActivity(it);
            }
        });



        return view;
    }
}

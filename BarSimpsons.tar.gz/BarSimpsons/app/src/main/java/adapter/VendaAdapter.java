package adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.example.barsimpsons.R;
import java.util.ArrayList;
import entity.Venda;


public class VendaAdapter extends BaseAdapter {

    ArrayList<Venda> lista;
    Context ctx;
    LayoutInflater layout;

    public VendaAdapter (Context ctx, ArrayList<Venda> lista) {
        this.ctx = ctx;
        this.lista = lista;
        layout = LayoutInflater.from(ctx);
    }

    public int getCount() {
        return lista.size();
    }

    public Object getItem(int i){
        return lista.get(i);
    }

    public long getItemId(int pos) {
        return lista.get(pos).getIdVenda();
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        final Venda item = (Venda) getItem(i);
        view = layout.inflate(R.layout.relatorio, null);

        TextView viewHora = (TextView) view.findViewById(R.id.viewHora);
        TextView viewProdutos = (TextView) view.findViewById(R.id.viewProdutos);
        TextView viewTotal = (TextView) view.findViewById(R.id.viewTotal);

        viewHora.setText(item.getDataVenda());
        viewProdutos.setText(item.getLista().toString());
        viewTotal.setText("¢" + item.getTotal().toString());

        return view;
    }

}

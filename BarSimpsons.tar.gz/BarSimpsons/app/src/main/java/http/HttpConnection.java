package http;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class HttpConnection {


    public static String httpGet(String url) {
        try {
            HttpClient cliente = new DefaultHttpClient();
            HttpGet httpGet = new HttpGet(url);
            HttpResponse resp = cliente.execute(httpGet);
            BufferedReader bf = new BufferedReader(
                    new InputStreamReader(resp.getEntity().getContent())
            );

            return bf.readLine();
        } catch (Exception ex) {
            return ex.getMessage();
        }

    }


}
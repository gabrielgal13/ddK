package async;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;
import com.google.common.net.UrlEscapers;
import entity.Pessoa;
import http.HttpConnection;

public class UsuarioCadastrarAsync extends AsyncTask<String,Void,String> {


    private Context context;
    private Pessoa pessoa;

    public UsuarioCadastrarAsync(Context context, Pessoa pessoa){
        this.context = context;
        this.pessoa = pessoa;
    }



    @Override
    protected String doInBackground(String... strings) {
        try {
            String thePath = "/" + pessoa.getNome() + "/" + pessoa.getLogin() + "/" + pessoa.getSenha() + "/" + pessoa.getEmail() + "/" + pessoa.getCep() + "/" +
                    pessoa.getLogradouro() + "/" + pessoa.getBairro() + "/" + pessoa.getCidade() + "/" + pessoa.getEstado();

            String encodedString = UrlEscapers.urlFragmentEscaper().escape(thePath);

            String resposta =
                    HttpConnection.httpGet(
                            "http://192.168.1.151:3008/cliente/gravar" +  encodedString );
            return resposta;
        }catch(Exception ex){
            return "Error :" + ex.getMessage();
        }
    }

    public void onPostExecute(String resposta){
        Toast.makeText(context, "Ok:" + resposta, Toast.LENGTH_SHORT).show();

    }


}

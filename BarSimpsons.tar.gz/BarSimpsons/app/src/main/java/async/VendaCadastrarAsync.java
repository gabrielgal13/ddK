package async;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;
import com.google.common.net.UrlEscapers;
import entity.Venda;
import http.HttpConnection;


public class VendaCadastrarAsync extends AsyncTask<String,Void,String> {

    private Context context;
    private Venda venda;

    public VendaCadastrarAsync(Context context, Venda venda){
        this.context = context;
        this.venda = venda;
    }

    @Override
    protected String doInBackground(String... strings) {
        try {
            String thePath = "/" + venda.getDataVenda() + "/" + venda.getNome() +"/" + venda.getLista() +"/" + venda.getTotal() +"/";
            String encodedString = UrlEscapers.urlFragmentEscaper().escape(thePath);


            String resposta =
                    HttpConnection.httpGet("http://192.168.1.151:3008/venda/cadastrar" + encodedString);
            return resposta;
        }catch(Exception ex){
            return "Error :" + ex.getMessage();
        }
    }

    public void onPostExecute(String resposta){
        Toast.makeText(context, "Ok:" + resposta, Toast.LENGTH_SHORT).show();

    }
}

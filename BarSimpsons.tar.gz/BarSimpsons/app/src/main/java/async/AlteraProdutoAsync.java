package async;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;
import entity.Produto;
import http.HttpConnection;

public class AlteraProdutoAsync extends AsyncTask<String,Void,String> {

    private Context context;
    private Produto produto;

    public AlteraProdutoAsync(Context context, Produto produto){
        this.context = context;
        this.produto = produto;
    }



    @Override
    protected String doInBackground(String... strings) {
        try {

            String resposta =
                    HttpConnection.httpGet(
                            "http://192.168.1.151:3008/produto/alterar/" + produto.getId() + "/" + produto.getNomeProduto() + "/" + produto.getPreco() + "/" + produto.getQuantidade() + "/");
            return resposta;
        }catch(Exception ex){
            return "Error :" + ex.getMessage();
        }
    }

    public void onPostExecute(String resposta){
        Toast.makeText(context, "Ok:" + resposta, Toast.LENGTH_SHORT).show();

    }

}

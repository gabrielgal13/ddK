var express = require("express");
var MongoClient = require("mongodb").MongoClient;
var bodyParser = require('body-parser');
var url = "mongodb://127.0.0.1:27018";
var app = express();

console.log('\x1Bc'); //clear

//Config
app.use(bodyParser.json()) // parse application/json
app.use(function (req, res, next) { //CORS Config
    res.header('Access-Control-Allow-Origin', '*');
    res.header("Access-Control-Allow-Credentials", "true");
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, X-Codingpedia, Authorization');
    next();
});

//listar todos os usuarios 
app.get("/clientes", function (req, res) {
    MongoClient.connect(url, function (err, database) {
        if (err) {
            console.log(err);
        } else {
            var db = database.db("barSimpsons");
        db.collection("cliente").find().toArray(function (err, data) {
                res.send(data);
                database.close();
            });
        }
    });
});

//gravar login e senha

app.get("/cliente/gravar/:nome/:login/:senha/:email/:cep/:logradouro/:bairro/:cidade/:estado", function (req, res) {
    MongoClient.connect(url, function (err, database) {
        if (err) {
            console.log(err);
        } else {
            var db = database.db("barSimpsons");
            var collection = db.collection("cliente");
            var vnome = req.param("nome");
            var vlogin = req.param("login");
            var vsenha = req.param("senha");
            var vemail = req.param("email");
            var vcep = req.param("cep");
            var vlogradouro = req.param("logradouro");
            var vbairro = req.param("bairro");
            var vcidade = req.param("cidade");
            var vestado = req.param("estado");
            console.log(req.body);
 collection.insertMany([{"nome":vnome,"login":vlogin,"senha":vsenha, "email":vemail,"cep":vcep, "logradouro":vlogradouro, "bairro":vbairro,
  "cidade":vcidade, "estado":vestado, "prioridade":1}],
          function (err, documents) {
                res.send({ error: err, affected: documents });
                database.close();
            });
        }
    });
});

//gravar Produto

app.get("/produto/gravar/:id/:nome/:preco/:quantidade/", function (req, res) {
    MongoClient.connect(url, function (err, database) {
        if (err) {
            console.log(err);
        } else {
            var db = database.db("barSimpsons");
            var collection = db.collection("produto");
            var vnome = req.param("nome");
            var vid = req.param("id");
            var vpreco= req.param("preco");
            var vquantidade = req.param("quantidade");
      
            console.log(req.body);
 collection.insertMany([{"id":vid,"nome":vnome,"preco":vpreco,"quantidade":vquantidade}],
          function (err, documents) {
                res.send({ error: err, affected: documents });
                database.close();
            });
        }
    });
});

//listar todos os produtos
app.get("/produtos", function (req, res) {
    MongoClient.connect(url, function (err, database) {
        if (err) {
            console.log(err);
        } else {
            var db = database.db("barSimpsons");
        db.collection("produto").find().toArray(function (err, data) {
                res.send(data);
                database.close();
            });
        }
    });
});

//listar todas as vendas
app.get("/vendas", function (req, res) {
    MongoClient.connect(url, function (err, database) {
        if (err) {
            console.log(err);
        } else {
            var db = database.db("barSimpsons");
        db.collection("vendas").find().toArray(function (err, data) {
                res.send(data);
                database.close();
            });
        }
    });
});


//listar vendas de cliente
app.get("/vendas/:nome", function (req, res) {
    MongoClient.connect(url, function (err, database) {
        if (err) {
            console.log(err);
        } else {
            var db = database.db("barSimpsons");
            var vnome = req.param("nome");
            db.collection("vendas").find({"NomeCliente":vnome}).toArray(function (err, data) {
                res.send(data);
                database.close();
            });
        }
    });
});


//gravar Produto

app.get("/produto/gravar/:id/:nome/:preco/:quantidade/", function (req, res) {
    MongoClient.connect(url, function (err, database) {
        if (err) {
            console.log(err);
        } else {
            var db = database.db("barSimpsons");
            var collection = db.collection("produto");
            var vnome = req.param("nome");
            var vid = req.param("id");
            var vpreco= req.param("preco");
            var vquantidade = req.param("quantidade");
      
            console.log(req.body);
 collection.insertMany([{"id":vid,"nome":vnome,"preco":vpreco,"quantidade":vquantidade}],
          function (err, documents) {
                res.send({ error: err, affected: documents });
                database.close();
            });
        }
    });
});


//Alterar produto
app.get("/produto/alterar/:id/:nome/:preco/:quantidade/", function (req, res) {
    MongoClient.connect(url, function (err, database) {
        if (err) {
            console.log(err);
        } else {
            var db = database.db("barSimpsons");
            var collection = db.collection("produto");
            var vnome = req.param("nome");
            var vid = req.param("id");
            var vpreco= req.param("preco");
            var vquantidade = req.param("quantidade");
      
            console.log(req.body);
   collection.updateOne({"id":vid},{$set:{"nome":vnome,"preco":vpreco,"quantidade":vquantidade}},
          function (err, documents) {
                res.send({ error: err, affected: documents });
                database.close();
            });
        }
    });
});

//Cadastrar Venda
app.get("/venda/cadastrar/:data/:nome/:produtos/:total/", function (req, res) {
    MongoClient.connect(url, function (err, database) {
        if (err) {
            console.log(err);
        } else {
            var db = database.db("barSimpsons");
            var collection = db.collection("vendas");
            var vnome = req.param("nome");
            var vdata = req.param("data");
            var vprodutos= req.param("produtos");
            var vtotal = req.param("total");
      
            console.log(req.body);
        collection.insertOne({"data":vdata,"NomeCliente":vnome,"produtos":vprodutos,"total":vtotal},
          function (err, documents) {
                res.send({ error: err, affected: documents });
                database.close();
            });
        }
    });
});

//Login
app.get("/pessoa/logar/:login/:senha", function (req, res) {
    MongoClient.connect(url, function (err, database) {
        if (err) {
            console.log(err);
        } else {
            var db = database.db("barSimpsons");
            var collection = db.collection("cliente");
            collection.find({"$and":[{"login": (req.param("login")) },
                                    {"senha": (req.param("senha")) }
                                   ]}
                                
            ).
         
                toArray(function (err, data) {
                    res.send(data);
                    database.close();
                });
        }
    });
    
});
 

var server = app.listen(3008, "0.0.0.0", function () {
    var host = server.address().address;
    var port = server.address().port;
    console.log("Listening at http://%s:%s", host, port);
});


package mock;

import com.example.applutadores2.R;

import java.util.ArrayList;

import entity.Lutador;

public class ManagerMock {

    private static final ArrayList<Lutador> lutadores = new ArrayList<>();

    static {
        int id=0;

        Lutador lu0 = new Lutador(id++,"Selecione o Lutador","none","none",0, "none");

                Lutador lu1 = new Lutador(id++,"Minotauro","Peso Pesado","Hall da Fama", R.drawable.minotauro, null );
                lu1.setSite("https://www.youtube.com/embed/AtHOBzsQBYA");
        lu1.setSitePessoal("https://pt.wikipedia.org/wiki/Ant%C3%B4nio_Rodrigo_Nogueira");
                Lutador lu2 = new Lutador(id++,"Lyoto","Peso medio","Decima posicao", R.drawable.lyoto, null);
                        lu2.setSite("https://www.youtube.com/embed/eh9gRJ5kM2k");
        lu2.setSitePessoal("https://www.lyotomachidaoficial.com.br");
        Lutador lu3 = new Lutador(id++,"Anderson Silva","Peso Medio"," 45 posicao", R.drawable.anderson,null );
        lu3.setSite("https://www.youtube.com/embed/vXXYZhyGvGo");
        lu3.setSitePessoal("https://pt.wikipedia.org/wiki/AndersonSilva");
        Lutador lu4 = new Lutador(id++,"Rikson Gracie","Absoluto","Hall da Fama", R.drawable.rikson, null);
        lu4.setSite("https://www.youtube.com/embed/Tb9H7hnKYVQ");
        lu4.setSitePessoal("https://www.ricksongracie.com/");
        lutadores.add(lu0);
        lutadores.add(lu1);
        lutadores.add(lu2);
        lutadores.add(lu3);
        lutadores.add(lu4);
    }

    public static ArrayList<Lutador> getLutadores(){
        return lutadores;
    }
}

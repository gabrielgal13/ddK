package entity;

import java.io.Serializable;

public class Lutador implements Serializable {
    private Integer id;
    private String nome;
    private String peso;
    private String ranking;
    private Integer foto=0;
    private String site;
    private String sitePessoal;

    public Lutador(Integer id, String nome, String peso, String ranking, Integer foto, String sitePessoal) {
        this.id = id;
        this.nome = nome;
        this.peso = peso;
        this.ranking = ranking;
        this.foto = foto;
        this.sitePessoal = sitePessoal;
    }

    @Override
    public String toString() {
        return nome;
    }


    public Lutador() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public String getRanking() {
        return ranking;
    }

    public void setRanking(String ranking) {
        this.ranking = ranking;
    }

    public Integer getFoto() {
        return foto;
    }

    public void setFoto(Integer foto) {
        this.foto = foto;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public String getSitePessoal() {
        return sitePessoal;
    }

    public void setSitePessoal(String sitePessoal) {
        this.sitePessoal = sitePessoal;
    }
}

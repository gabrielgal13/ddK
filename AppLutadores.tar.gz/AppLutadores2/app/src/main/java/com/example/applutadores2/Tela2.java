package com.example.applutadores2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import entity.Lutador;
import mock.ManagerMock;

public class Tela2 extends AppCompatActivity {
    EditText txtNome, txtPeso, txtRanking, txtPontuacao, txtSiteLutador;
    ImageView foto;
    Spinner splutadores;
    Lutador lutador;
    ArrayList<Lutador> lutadores;
    ArrayAdapter<Lutador> adapter;
    int pos=0;
    WebView webview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        lutadores = ManagerMock.getLutadores();
        Toast.makeText(this,"lutadores"+ lutadores.toString(), Toast.LENGTH_LONG).show();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, lutadores);
        splutadores = findViewById(R.id.splutadores);
        splutadores.setAdapter(adapter);
        webview = findViewById(R.id.webview);
        txtSiteLutador = findViewById(R.id.txtSiteLutador);
        txtNome = findViewById(R.id.txtNome);
        txtPeso = findViewById(R.id.txtPeso);
        txtRanking = findViewById(R.id.txtRanking);
        foto = findViewById(R.id.foto);
        splutadores.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int i, long id) {
                pos = i;
                lutador = ManagerMock.getLutadores().get(i);
                ManagerMock.getLutadores().set(i,lutador);
                Toast.makeText(getApplicationContext(), lutador.toString(), Toast.LENGTH_LONG).show();
                txtNome.setText(lutador.getNome().toString());
                txtPeso.setText(lutador.getPeso().toString());
                txtRanking.setText(lutador.getRanking().toString());
                foto.setImageResource(lutador.getFoto());
                txtSiteLutador.setText(lutador.getSitePessoal().toString());
                webview.getSettings().setJavaScriptEnabled(true);
                webview.setWebChromeClient(new
                        WebChromeClient());
                webview.getSettings().setLoadWithOverviewMode(true);
                String url ="<iframe \"youtube-player\"type=\"text/html5\" width=\"250\" height=\"260\"style=\"border:1px solid\" "+"src="+lutador.getSite()+"></iframe>";
                webview.loadData(url,"text/html",null);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void mostrar(View v){
// Uri uri = Uri.parse(lutador.getSitePessoal());
        Uri uri = Uri.parse(lutador.getSite());
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }
}
